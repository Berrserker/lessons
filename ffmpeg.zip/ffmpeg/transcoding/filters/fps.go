package filters

import "strconv"

type FpsFilter struct {
	basic
	Fps float64
}

func (ff FpsFilter) AsString() string {
	const (
		filterName = "fps"
		fpsKey     = "fps"
	)

	if ff.Fps != 0 {
		ff.addParam(fpsKey, strconv.FormatFloat(ff.Fps, 'f', 3, 64))
	}

	ff.name = filterName

	return ff.asString()
}

func (ff FpsFilter) isValid() error {
	switch {
	case ff.Fps < 0:
		return ErrFpsIsNegative
	default:
		return nil
	}
}
