package filters

import (
	"fmt"
	"strings"
)

type basic struct {
	name string
	args map[string]string
}

func (b *basic) addParam(key, value string) {
	if b.args == nil {
		b.args = make(map[string]string)
	}

	b.args[key] = value
}

func (b *basic) asString() string {
	if len(b.args) == 0 {
		return b.name
	}

	filterArgs := []string{}

	for k, v := range b.args {
		filterArgs = append(filterArgs, fmt.Sprintf("%s=%s", k, v))
	}

	return fmt.Sprintf("%s=%s", b.name, strings.Join(filterArgs, ":"))
}
