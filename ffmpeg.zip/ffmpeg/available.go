package ffmpeg

import (
	"context"

	"gitlab.infra.aiarlabs.com/media/ffmpeg/args"
	"gitlab.infra.aiarlabs.com/media/ffmpeg/executors"
	"gitlab.infra.aiarlabs.com/media/ffmpeg/parsers"
)

func getAvailableEncoders(pathToBin string) (map[string]*parsers.AvailableEncDec, error) {
	result := map[string]*parsers.AvailableEncDec{}

	onProgress := func(line string) {
		enc, err := parsers.ParseAvailableEncDec(line)
		if err != nil {
			return
		}

		result[enc.Name] = enc
	}

	if err := executors.WithOutputPipe(
		context.TODO(),
		pathToBin,
		args.GetAvailableEncodersArgs(),
		onProgress); err != nil {
		return nil, err
	}

	return result, nil
}

func getAvailableDecoders(pathToBin string) (map[string]*parsers.AvailableEncDec, error) {
	result := map[string]*parsers.AvailableEncDec{}

	onProgress := func(line string) {
		dec, err := parsers.ParseAvailableEncDec(line)
		if err != nil {
			return
		}

		result[dec.Name] = dec
	}

	if err := executors.WithOutputPipe(
		context.TODO(),
		pathToBin,
		args.GetAvailableDecodersArgs(),
		onProgress); err != nil {
		return nil, err
	}

	return result, nil
}

func getAvailableFilters(pathToBin string) (map[string]*parsers.AvailableFilter, error) {
	result := map[string]*parsers.AvailableFilter{}

	onProgress := func(line string) {
		f, err := parsers.ParseAvailableFilter(line)
		if err != nil {
			return
		}

		result[f.Name] = f
	}

	if err := executors.WithOutputPipe(
		context.TODO(),
		pathToBin,
		args.GetAvailableFiltersArgs(),
		onProgress); err != nil {
		return nil, err
	}

	return result, nil
}

func getAvailableFormats(pathToBin string) (map[string]*parsers.AvailableFormat, error) {
	result := map[string]*parsers.AvailableFormat{}

	onProgress := func(line string) {
		f, err := parsers.ParseAvailableFormat(line)
		if err != nil {
			return
		}

		result[f.Name] = f
	}

	if err := executors.WithOutputPipe(
		context.TODO(),
		pathToBin,
		args.GetAvailableFormatsArgs(),
		onProgress); err != nil {
		return nil, err
	}

	return result, nil
}

func getAvailablePixelFormats(pathToBin string) (map[string]*parsers.AvailablePixelFormat, error) {
	result := map[string]*parsers.AvailablePixelFormat{}

	onProgress := func(line string) {
		f, err := parsers.ParseAvailablePixelFormat(line)
		if err != nil {
			return
		}

		result[f.Name] = f
	}

	if err := executors.WithOutputPipe(
		context.TODO(),
		pathToBin,
		args.GetAvailablePixelFormatsArgs(),
		onProgress); err != nil {
		return nil, err
	}

	return result, nil
}
