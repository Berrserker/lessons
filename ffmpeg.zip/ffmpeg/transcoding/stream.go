package transcoding

type StreamType string

const (
	VideoStream StreamType = "v"
	AudioStream StreamType = "a"
)
