package parsers

import "errors"

var (
	ErrBadSubmatch = errors.New("bad submatch")
)
