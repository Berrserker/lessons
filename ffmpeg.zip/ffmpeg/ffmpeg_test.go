package ffmpeg

import (
	"context"
	"log"
	"testing"

	"github.com/stretchr/testify/assert"

	"gitlab.infra.aiarlabs.com/media/ffmpeg/transcoding"
	"gitlab.infra.aiarlabs.com/media/ffmpeg/transcoding/filters"
)

func TestGetAvailableFilters(t *testing.T) {
	const binPath = "/usr/local/bin/ffmpeg"

	type filterTests struct {
		filterName string
		err        error
	}

	okTests := []filterTests{
		{
			filterName: "ssim",
			err:        nil,
		},
		{
			filterName: "scale",
			err:        nil,
		},
	}

	failedTests := []filterTests{
		{
			filterName: "super_scale",
			err:        ErrNotAvailable,
		},
	}

	mod, _ := New(binPath)

	for _, currTest := range okTests {
		f, err := mod.FilterIsAvailable(currTest.filterName)
		assert.Nil(t, err)
		assert.NotNil(t, f)
	}

	for _, currTest := range failedTests {
		f, err := mod.FilterIsAvailable(currTest.filterName)
		assert.NotNil(t, err)
		assert.Nil(t, f)
		assert.Equal(t, err, currTest.err)
	}
}

func TestGetAvailableFormats(t *testing.T) {
	const binPath = "/usr/local/bin/ffmpeg"

	type formatTests struct {
		formatName string
		err        error
	}

	okTests := []formatTests{
		{
			formatName: "mp4",
			err:        nil,
		},
		{
			formatName: "ogg",
			err:        nil,
		},
	}

	failedTests := []formatTests{
		{
			formatName: "no_format",
			err:        ErrNotAvailable,
		},
	}

	mod, _ := New(binPath)

	for _, currTest := range okTests {
		f, err := mod.FormatIsAvailable(currTest.formatName)
		assert.Nil(t, err)
		assert.NotNil(t, f)
	}

	for _, currTest := range failedTests {
		f, err := mod.FormatIsAvailable(currTest.formatName)
		assert.NotNil(t, err)
		assert.Nil(t, f)
		assert.Equal(t, err, currTest.err)
	}
}

func TestFfmpegRunTask(t *testing.T) {
	const binPath = "/usr/local/bin/ffmpeg"

	mod, _ := New(binPath)

	setting := transcoding.Job{
		Rewrite:      true,
		WithProgress: true,
		Inputs:       []transcoding.Input{{Path: "samples/test.mp4"}},
		Outputs: []transcoding.Output{
			{
				Path:   "samples/output.mp4",
				Format: "mp4",
				Video: transcoding.Video{

					Codec: &transcoding.Codec{Name: "libx264"},
					Mapping: &transcoding.Mapping{
						InputIndex:  0,
						StreamType:  transcoding.VideoStream,
						StreamIndex: 0,
					},
					Crf:         32,
					PixelFormat: "yuv420p",
					Filters: []filters.Filter{
						filters.ScaleFilter{
							Width:  -2,
							Height: 640,
						},
						filters.SarFilter{
							PixelWidth:  1,
							PixelHeight: 1,
						},
					},
				},
				Audio: transcoding.Audio{
					Codec: &transcoding.Codec{Name: "aac"},
					Mapping: &transcoding.Mapping{
						InputIndex:  0,
						StreamType:  transcoding.AudioStream,
						StreamIndex: 0,
					},
					Channels:   1,
					SampleRate: 44100,
				},
				Movflags: []string{"faststart"},
			},
		},
	}

	onProgress := func(progress *Progress) {
		log.Println(progress.Time)
	}

	err := mod.RunTask(context.TODO(), setting, onProgress)
	assert.Nil(t, err)
}
