package transcoding

import "gitlab.infra.aiarlabs.com/media/ffmpeg/args"

type Audio struct {
	Copy, None bool
	Codec      *Codec
	Bitrate    *Bitrate
	Mapping    *Mapping
	Channels   int
	SampleRate int
}

func (a *Audio) isValid() error {
	if a.Codec != nil {
		if err := a.Codec.isValid(); err != nil {
			return err
		}
	}

	if a.Bitrate != nil {
		if err := a.Bitrate.isValid(); err != nil {
			return err
		}
	}

	switch {
	case a.Channels <= 0:
		return ErrIsNegative
	case a.SampleRate <= 0:
		return ErrIsNegative
	default:
		return nil
	}
}

func (a *Audio) getArgs() []string {
	result := []string{}

	if a.None {
		return append(result, args.GetNoneStreamArg(string(AudioStream)))
	}

	if a.Mapping != nil {
		result = append(result, a.Mapping.getArgs()...)
	}

	if a.Copy {
		result = append(result, args.GetCodecCopyArgs(string(AudioStream))...)

		return result
	}

	if a.Codec != nil {
		result = append(result, a.Codec.getArgs(AudioStream)...)
	}

	if a.Bitrate != nil {
		result = append(result, a.Bitrate.getArgs(AudioStream)...)
	}

	if a.Channels != 0 {
		result = append(result, args.GetChannelsArgs(a.Channels)...)
	}

	if a.SampleRate != 0 {
		result = append(result, args.GetAudioSampleRate(a.SampleRate)...)
	}

	return result
}
