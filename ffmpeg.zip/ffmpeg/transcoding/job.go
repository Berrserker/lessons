package transcoding

import (
	"gitlab.infra.aiarlabs.com/media/ffmpeg/args"
)

type Job struct {
	Rewrite      bool
	WithProgress bool
	Inputs       []Input
	Outputs      []Output
}

func (j *Job) GetArgs() ([]string, error) {
	result := []string{args.GetHideBannerArg()}
	if j.Rewrite {
		result = append(result, args.GetRewriteArg())
	}

	if j.WithProgress {
		result = append(result, args.GetProgressArgs("-")...)
	}

	for _, currInput := range j.Inputs {
		a, err := currInput.getArgs()
		if err != nil {
			return nil, err
		}

		result = append(result, a...)
	}

	for _, currOutput := range j.Outputs {
		a, err := currOutput.getArgs()
		if err != nil {
			return nil, err
		}

		result = append(result, a...)
	}

	return result, nil
}
