package filters

import "errors"

var (
	ErrHeightIsNegative          = errors.New("height can't be negative")
	ErrWidthIsNegative           = errors.New("width can't be negative")
	ErrWidthOrHeightIsUnselected = errors.New("width or height must be both selected")
	ErrOutputsIsNegative         = errors.New("outputs can't be negative")
	ErrFrameIndexIsNegative      = errors.New("frame index can't be negative")
	ErrFpsIsNegative             = errors.New("fps can't be negative")
)
