package transcoding

import "gitlab.infra.aiarlabs.com/media/ffmpeg/args"

type GOP struct {
	Min, Max int
}

func (g *GOP) isValid() error {
	switch {
	case g.Max < 0, g.Min < 0:
		return ErrIsNegative
	case g.Max < g.Min:
		return ErrMaxLessThanMin
	default:
		return nil
	}
}

func (g *GOP) getArgs() []string {
	result := []string{}
	if g.Min != 0 {
		result = append(result, args.GetGopArgs(g.Min)...)
	}

	if g.Max != 0 {
		result = append(result, args.GetKeyIntMinArgs(g.Max)...)
	}

	return result
}
