package filters

import (
	"fmt"
	"strconv"
)

type SelectFilter struct {
	basic
	Expr    string
	Outputs int
}

func (sf SelectFilter) AsString() string {
	const (
		filterName = "select"
		exprKey    = "e"
		outputsKey = "n"
	)

	if sf.Expr != "" {
		sf.addParam(exprKey, sf.Expr)
	}

	if sf.Outputs != 0 {
		sf.addParam(outputsKey, strconv.Itoa(sf.Outputs))
	}

	sf.name = filterName

	return sf.asString()
}

func (sf SelectFilter) isValid() error {
	switch {
	case sf.Outputs < 0:
		return ErrOutputsIsNegative
	default:
		return nil
	}
}

// SELECT FRAME BY INDEX

type SelectFrameByPosition struct {
	SelectFilter
	Index int
}

func (sf SelectFrameByPosition) AsString() string {
	sf.Expr = fmt.Sprintf("(gte(n\\,%d))*not(mod(n\\,%d))", sf.Index, sf.Index)

	return sf.SelectFilter.AsString()
}

func (sf SelectFrameByPosition) isValid() error {
	switch {
	case sf.Index < 0:
		return ErrFrameIndexIsNegative
	default:
		return sf.SelectFilter.isValid()
	}
}
