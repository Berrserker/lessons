package parsers

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestParseEncDec(t *testing.T) {
	type encParserTest struct {
		input  string
		result *AvailableEncDec
		err    error
	}

	testsOk := []encParserTest{
		{
			input: "V..... a64multi             Multicolor charset for Commodore 64 (codec a64_multi)",
			result: &AvailableEncDec{
				Name:   "a64multi",
				Desc:   "Multicolor charset for Commodore 64 (codec a64_multi)",
				IOType: IOVideo,
			},
		},
	}

	for _, currTest := range testsOk {
		result, err := ParseAvailableEncDec(currTest.input)
		assert.Nil(t, err)
		assert.NotNil(t, result)
		assert.EqualValues(t, currTest.result, result)
	}

	testsFailed := []encParserTest{
		{
			input: "C... dd dssd             Ololo (ololo)",
			err:   ErrBadSubmatch,
		},
	}
	for _, currTest := range testsFailed {
		result, err := ParseAvailableEncDec(currTest.input)
		assert.NotNil(t, err)
		assert.Nil(t, result)
		assert.EqualValues(t, currTest.err, err)
	}
}
