package ffmpeg

import "errors"

var (
	ErrNoPathToBin  = errors.New("no path to binary file")
	ErrNotAvailable = errors.New("not available")
)
