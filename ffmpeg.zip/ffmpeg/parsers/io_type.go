package parsers

type IOType int

const (
	IOVideo IOType = iota
	IOAudio
	IOSubtitles
	IODynamic
	IOSourceOrSinkFilter
)

func parseIOType(input string) IOType {
	switch input {
	case "V":
		return IOVideo
	case "A":
		return IOAudio
	case "S":
		return IOSubtitles
	case "|":
		return IOSourceOrSinkFilter
	default:
		return IODynamic
	}
}
