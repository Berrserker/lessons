package ffmpeg

import (
	"context"
	"fmt"
	"os/exec"

	"gitlab.infra.aiarlabs.com/media/ffmpeg/executors"
	"gitlab.infra.aiarlabs.com/media/ffmpeg/parsers"
	"gitlab.infra.aiarlabs.com/media/ffmpeg/transcoding"
)

// Ffmpeg является структурой для работы модуля
type Ffmpeg struct {
	binPath            string
	encoders, decoders map[string]*parsers.AvailableEncDec
	filters            map[string]*parsers.AvailableFilter
	formats            map[string]*parsers.AvailableFormat
	pixelFormats       map[string]*parsers.AvailablePixelFormat
}

// New возвращает инстанс модуля и проверяет информацию о поддерживаемых медиа контейнерах, енкодерах/декодерах и
// прочих нужных вещах. В случае проблем инициализации выводит ошибку.
func New(utilPath string) (*Ffmpeg, error) {
	// validation
	if err := validation(utilPath); err != nil {
		return nil, err
	}

	if err := isInstalled(utilPath); err != nil {
		return nil, err
	}

	decoders, err := getAvailableDecoders(utilPath)
	if err != nil {
		return nil, err
	}

	encoders, err := getAvailableEncoders(utilPath)
	if err != nil {
		return nil, err
	}

	filters, err := getAvailableFilters(utilPath)
	if err != nil {
		return nil, err
	}

	formats, err := getAvailableFormats(utilPath)
	if err != nil {
		return nil, err
	}

	pixelFormats, err := getAvailablePixelFormats(utilPath)
	if err != nil {
		return nil, err
	}

	return &Ffmpeg{
		binPath:      utilPath,
		encoders:     encoders,
		decoders:     decoders,
		filters:      filters,
		formats:      formats,
		pixelFormats: pixelFormats,
	}, nil
}

// FormatIsAvailable проверяет по названию енкодера поддерживается ли он в текущей сборке
// Возвращает все параметры доступного енкодера и ошибку
func (m *Ffmpeg) EncoderIsAvailable(name string) (*parsers.AvailableEncDec, error) {
	if enc, ok := m.encoders[name]; ok  {
		return enc, nil
	}

	return nil, ErrNotAvailable
}

// FormatIsAvailable проверяет по названию медиа формата поддерживается ли он в текущей сборке
// Возвращает все параметры доступного медиа формата и ошибку
func (m *Ffmpeg) FormatIsAvailable(name string) (*parsers.AvailableFormat, error) {
	if format, ok := m.formats[name]; ok {
		return format, nil
	}

	return nil, ErrNotAvailable
}

// DecoderIsAvailable проверяет по названию декодера поддерживается ли он в текущей сборке
// Возвращает все параметры доступного декодера и ошибку
func (m *Ffmpeg) DecoderIsAvailable(name string) (*parsers.AvailableEncDec, error) {
	if dec, ok := m.decoders[name]; ok {
		return dec, nil
	}

	return nil, ErrNotAvailable
}

// FilterIsAvailable проверяет по названию фильтра поддерживается ли он в текущей сборке
// Возвращает все параметры доступного фильтра и ошибку
func (m *Ffmpeg) FilterIsAvailable(name string) (*parsers.AvailableFilter, error) {
	if filter, ok := m.filters[name]; ok {
		return filter, nil
	}

	return nil, ErrNotAvailable
}

// PixelFormatIsAvailable проверяет по названию формата пикселя поддерживается ли он в текущей сборке
// Возвращает все параметры доступного формата пикселя и ошибку
func (m *Ffmpeg) PixelFormatIsAvailable(name string) (*parsers.AvailablePixelFormat, error) {
	if pixFmt, ok := m.pixelFormats[name]; ok {
		return pixFmt, nil
	}

	return nil, ErrNotAvailable
}

// RunTask запускает FFMPEG-джобу с параметрами settings. Возвращает ошибку
func (m *Ffmpeg) RunTask(ctx context.Context, settings transcoding.Job, onProgress func(*Progress)) error {
	args, err := settings.GetArgs()
	if err != nil {
		return err
	}

	if onProgress == nil {
		if _, err := executors.WithOutput(ctx, m.binPath, args); err != nil {
			return err
		}
	}

	progress := &Progress{}
	currentFrame := 0

	onProgressCallback := func(input string) {
		progress.Update(input)

		if progress.Frame == currentFrame {
			return
		}

		currentFrame = progress.Frame
		onProgress(progress)
	}

	return executors.WithOutputPipe(ctx, m.binPath, args, onProgressCallback)
}

// isInstalled проверяет есть ли по данному пути бинарный файл.
// В случае если файл не найден - вернет ошибку.
func isInstalled(binPath string) error {
	if _, err := exec.LookPath(binPath); err != nil {
		return fmt.Errorf("no such util with path [%s]", binPath)
	}

	return nil
}

// validation проверяет валидность пути до бинарного файла
func validation(pathToBin string) error {
	switch {
	case pathToBin == "":
		return ErrNoPathToBin
	default:
		return nil
	}
}
