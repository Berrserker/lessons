package parsers

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestParseIOType(t *testing.T) {
	type ioTypeParserTest struct {
		input  string
		result IOType
	}

	tests := []ioTypeParserTest{
		{
			input:  "V",
			result: IOVideo,
		},
		{
			input:  "A",
			result: IOAudio,
		},
		{
			input:  "N",
			result: IODynamic,
		},
	}

	for _, currTest := range tests {
		result := parseIOType(currTest.input)
		assert.EqualValues(t, currTest.result, result)
	}
}
