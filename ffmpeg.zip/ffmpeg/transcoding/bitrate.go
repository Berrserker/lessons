package transcoding

import "gitlab.infra.aiarlabs.com/media/ffmpeg/args"

type Bitrate struct {
	Value int
}

func (b *Bitrate) getArgs(streamType StreamType) []string {
	return args.GetBitrateArgs(b.Value, string(streamType))
}

func (b *Bitrate) isValid() error {
	switch {
	case b.Value < 0:
		return ErrIsNegative
	default:
		return nil
	}
}
