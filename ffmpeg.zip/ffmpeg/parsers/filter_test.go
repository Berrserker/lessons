package parsers

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestParseFilters(t *testing.T) {
	type encParserTest struct {
		input  string
		result *AvailableFilter
		err    error
	}

	testsOk := []encParserTest{
		{
			input: "... ssim              VV->V      Calculate the SSIM between two video streams.",
			result: &AvailableFilter{
				Name: "ssim",
				Desc: "Calculate the SSIM between two video streams.",
				Input: FilterIO{
					ioType: IOVideo,
					count:  2,
				},
				Output: FilterIO{
					ioType: IOVideo,
					count:  1,
				},
			},
		},
	}

	for _, currTest := range testsOk {
		result, err := ParseAvailableFilter(currTest.input)
		assert.Nil(t, err)
		assert.NotNil(t, result)
		assert.EqualValues(t, currTest.result, result)
	}

	testsFailed := []encParserTest{
		{
			input: ".X. soso              XX->AA      Failed ko ko ko",
			err:   ErrBadSubmatch,
		},
	}

	for _, currTest := range testsFailed {
		result, err := ParseAvailableFilter(currTest.input)
		assert.NotNil(t, err)
		assert.Nil(t, result)
		assert.EqualValues(t, currTest.err, err)
	}
}
