package parsers

import "regexp"

type AvailableEncDec struct {
	Name                             string
	Desc                             string
	IOType                           IOType
	FrameLevelMultithreading         bool
	SliceLevelMultithreading         bool
	Experimental                     bool
	SupportsDrawHorizBand            bool
	SupportsDirectRenderingMethodOne bool
}

func ParseAvailableEncDec(input string) (*AvailableEncDec, error) {
	const (
		rExpr       = `^(\w+|.)(\w+|.)(\w|.)(\w|.)(\w|.)(\w|.)\s+(\S+)\s+(.+)$`
		totalParams = 9
	)

	r, err := regexp.Compile(rExpr)
	if err != nil {
		return nil, err
	}

	subm := r.FindStringSubmatch(input)
	if len(subm) < totalParams {
		return nil, ErrBadSubmatch
	}

	result := &AvailableEncDec{
		Name:                             subm[7],
		Desc:                             subm[8],
		IOType:                           parseIOType(subm[1]),
		FrameLevelMultithreading:         subm[2] != ".",
		SliceLevelMultithreading:         subm[3] != ".",
		Experimental:                     subm[4] != ".",
		SupportsDrawHorizBand:            subm[5] != ".",
		SupportsDirectRenderingMethodOne: subm[6] != ".",
	}

	return result, nil
}
