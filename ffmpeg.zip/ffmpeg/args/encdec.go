package args

// GOP

const (
	gopArg       = "-g"
	keyIntMinArg = "-keyint_min"
)

// CODEC

const codecArg = "-c"

// BITRATE

const (
	bitrateArg = "-b"
	maxrateArg = "-maxrate"
	bufsizeArg = "-bufsize"
)

// PROFILE

const profileArg = "-profile"

// LEVEL

const levelArg = "-level"

// PIXEL FORMAT

const pixelFormatArg = "-pix_fmt"

// CRF

const crfArg = "-crf"

// FORMAT

const formatArg = "-f"

// VIDEO FILTERS

const videoFiltersArg = "-vf"

// MOVFLAGS

const movFlagsArg = "-movflags"

// AUDIO CHANNELS

const audioChannelsArg = "-ac"

// AUDIO RATE

const audioRateArg = "-ar"

// VIDEO FRAME RATE

const frameRateArg = "-r"

// MAP

const mapArg = "-map"
