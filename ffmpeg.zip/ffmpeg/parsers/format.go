package parsers

import "regexp"

type AvailableFormat struct {
	Name              string
	Desc              string
	DemuxingSupported bool
	MuxingSupported   bool
}

func ParseAvailableFormat(input string) (*AvailableFormat, error) {
	const (
		rExpr       = `^\s(\w+|\s)(\w+|\s)\s+(\S+)\s+(.+)$`
		totalParams = 5
	)

	r, err := regexp.Compile(rExpr)
	if err != nil {
		return nil, err
	}

	subm := r.FindStringSubmatch(input)
	if len(subm) < totalParams {
		return nil, ErrBadSubmatch
	}

	return &AvailableFormat{
		Name:              subm[3],
		Desc:              subm[4],
		DemuxingSupported: subm[1] != "D",
		MuxingSupported:   subm[2] != "E",
	}, nil
}
