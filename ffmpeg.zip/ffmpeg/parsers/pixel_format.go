package parsers

import (
	"regexp"
	"strconv"
)

type AvailablePixelFormat struct {
	Name                             string
	SupportInputFormatForConversion  bool
	SupportOutputFormatForConversion bool
	HardwareAcceleration             bool
	PalettedFormat                   bool
	BitstreamFormat                  bool
	NumberOfComponents               int
	BitsPerSample                    int
}

func ParseAvailablePixelFormat(input string) (*AvailablePixelFormat, error) {
	const (
		rExpr       = `^(\w+|.)(\w+|.)(\w|.)(\w|.)(\w|.)\s+(\S+)\s+(\d)\s+(\d+)$`
		totalParams = 9
	)

	r, err := regexp.Compile(rExpr)
	if err != nil {
		return nil, err
	}

	subm := r.FindStringSubmatch(input)
	if len(subm) < totalParams {
		return nil, ErrBadSubmatch
	}

	numberOfComponents, err := strconv.Atoi(subm[7])
	if err != nil {
		return nil, err
	}

	bitsPerSample, err := strconv.Atoi(subm[8])
	if err != nil {
		return nil, err
	}

	result := &AvailablePixelFormat{
		Name:                             subm[6],
		NumberOfComponents:               numberOfComponents,
		BitsPerSample:                    bitsPerSample,
		SupportInputFormatForConversion:  subm[1] != ".",
		SupportOutputFormatForConversion: subm[2] != ".",
		HardwareAcceleration:             subm[3] != ".",
		PalettedFormat:                   subm[4] != ".",
		BitstreamFormat:                  subm[5] != ".",
	}

	return result, nil
}
