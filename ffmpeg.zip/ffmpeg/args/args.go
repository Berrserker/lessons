package args

import (
	"fmt"
	"strconv"
	"strings"
)

func GetAvailableEncodersArgs() []string {
	return []string{hideBannerArg, availableEncodersArg}
}

func GetAvailableDecodersArgs() []string {
	return []string{hideBannerArg, availableDecodersArg}
}

func GetAvailableFiltersArgs() []string {
	return []string{hideBannerArg, availableFiltersArg}
}

func GetAvailableFormatsArgs() []string {
	return []string{hideBannerArg, availableFormatsArg}
}

func GetAvailablePixelFormatsArgs() []string {
	return []string{hideBannerArg, availablePixelFormatsArg}
}

func GetProgressArgs(to string) []string {
	return []string{progressArg, to}
}

func GetRewriteArg() string {
	return rewriteArg
}

func GetHideBannerArg() string {
	return hideBannerArg
}

func GetInputArg(value string) []string {
	return []string{inputArg, value}
}

func GetLogLevelArgs(value LogLevel) []string {
	return []string{logLevelArg, string(value)}
}

func GetFormatArgs(value string) []string {
	return []string{formatArg, value}
}

func GetGopArgs(value int) []string {
	return []string{gopArg, strconv.Itoa(value)}
}

func GetKeyIntMinArgs(value int) []string {
	return []string{keyIntMinArg, strconv.Itoa(value)}
}

func GetCodecCopyArgs(streamType string) []string {
	key := fmt.Sprintf("%s:%s", codecArg, streamType)

	return []string{key, "copy"}
}

func GetNoneStreamArg(streamType string) string {
	return fmt.Sprintf("-%sn", streamType)
}

func GetCodecArgs(value, streamType string) []string {
	arg := fmt.Sprintf("%s:%s", codecArg, streamType)

	return []string{arg, value}
}

func GetBitrateArgs(value int, streamType string) []string {
	arg := fmt.Sprintf("%s:%s", bitrateArg, streamType)

	return []string{arg, strconv.Itoa(value)}
}

func GetChannelsArgs(value int) []string {
	return []string{audioChannelsArg, strconv.Itoa(value)}
}

func GetAudioSampleRate(value int) []string {
	return []string{audioRateArg, strconv.Itoa(value)}
}

func GetBufsizeArgs(value int) []string {
	return []string{bufsizeArg, strconv.Itoa(value)}
}

func GetMaxrateArgs(value int) []string {
	return []string{maxrateArg, strconv.Itoa(value)}
}

func GetProfileArgs(value, streamType string) []string {
	arg := fmt.Sprintf("%s:%s", profileArg, streamType)

	return []string{arg, value}
}

func GetMovlagsArgs(value string) []string {
	return []string{movFlagsArg, value}
}

func GetFrameRateArgs(value float64) []string {
	return []string{frameRateArg, strconv.FormatFloat(value, 'f', 3, 64)}
}

func GetLevelArgs(value float64) []string {
	return []string{levelArg, strconv.FormatFloat(value, 'f', 1, 64)}
}

func GetPixelFormatArgs(value string) []string {
	return []string{pixelFormatArg, value}
}

func GetVideoFiltersArgs(filters []string) []string {
	return []string{videoFiltersArg, strings.Join(filters, ",")}
}

func GetMapArgs(value string) []string {
	return []string{mapArg, value}
}

func GetCrfArgs(value int) []string {
	return []string{crfArg, strconv.Itoa(value)}
}
