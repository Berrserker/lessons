package transcoding

import "gitlab.infra.aiarlabs.com/media/ffmpeg/args"

type Input struct {
	Decoder *Codec
	Path    string
}

func (i *Input) isValid() error {
	if i.Decoder != nil {
		if err := i.Decoder.isValid(); err != nil {
			return err
		}
	}

	switch {
	case i.Path == "":
		return ErrIsEmpty
	default:
		return nil
	}
}

func (i *Input) getArgs() ([]string, error) {
	if err := i.isValid(); err != nil {
		return nil, err
	}

	result := []string{}
	if i.Decoder != nil {
		result = append(result, i.Decoder.getArgs(VideoStream)...)
	}

	result = append(result, args.GetInputArg(i.Path)...)

	return result, nil
}
