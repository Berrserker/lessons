package transcoding

import "gitlab.infra.aiarlabs.com/media/ffmpeg/args"

type Output struct {
	Path     string
	Format   string
	Video    Video
	Audio    Audio
	Movflags []string
}

func (o *Output) isValid() error {
	if err := o.Video.isValid(); err != nil {
		return err
	}

	if err := o.Audio.isValid(); err != nil {
		return err
	}

	switch {
	case o.Path == "":
		return ErrIsEmpty
	default:
		return nil
	}
}

func (o *Output) getArgs() ([]string, error) {
	if err := o.isValid(); err != nil {
		return nil, err
	}

	result := []string{}

	result = append(result, o.Video.getArgs()...)

	result = append(result, o.Audio.getArgs()...)

	if o.Format != "" {
		result = append(result, args.GetFormatArgs(o.Format)...)
	}

	for _, mf := range o.Movflags {
		result = append(result, args.GetMovlagsArgs(mf)...)
	}

	return append(result, o.Path), nil
}
