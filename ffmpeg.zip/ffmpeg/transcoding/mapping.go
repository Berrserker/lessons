package transcoding

import (
	"fmt"

	"gitlab.infra.aiarlabs.com/media/ffmpeg/args"
)

type Mapping struct {
	InputIndex  uint8
	StreamType  StreamType
	StreamIndex uint8
}

func (m *Mapping) valueToString() string {
	switch m.StreamType {
	case VideoStream, AudioStream:
		return fmt.Sprintf("%d:%s:%d", m.InputIndex, m.StreamType, m.StreamIndex)
	default:
		return fmt.Sprintf("%d:%d", m.InputIndex, m.StreamIndex)
	}
}

func (m *Mapping) getArgs() []string {
	return args.GetMapArgs(m.valueToString())
}
