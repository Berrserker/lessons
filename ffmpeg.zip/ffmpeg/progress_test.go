package ffmpeg

import (
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
)

func TestUpdateProgress(t *testing.T) {
	type progressParserTest struct {
		old   *Progress
		input string
		new   *Progress
	}

	tests := []progressParserTest{
		{
			input: "frame=383",
			old:   &Progress{Frame: 123},
			new:   &Progress{Frame: 383},
		},
		{
			input: "out_time_us=123123123",
			old:   &Progress{Time: 123123000 * time.Nanosecond},
			new:   &Progress{Time: 123123123},
		},
		{
			input: "fps=34.9",
			old:   &Progress{Fps: 12.3},
			new:   &Progress{Fps: 34.9},
		},
		{
			input: "bitrate=5048.7kbits/s",
			old:   &Progress{Bitrate: 5000.0},
			new:   &Progress{Bitrate: 5048.7},
		},
		{
			input: "speed=2.32x",
			old:   &Progress{Speed: 1.1},
			new:   &Progress{Speed: 2.32},
		},
		{
			input: "progress=continue",
			old:   &Progress{EndFlag: false},
			new:   &Progress{EndFlag: false},
		},
		{
			input: "progress=end",
			old:   &Progress{EndFlag: false},
			new:   &Progress{EndFlag: true},
		},
		{
			input: "total_size=3407920",
			old:   &Progress{Size: 2464034},
			new:   &Progress{Size: 3407920},
		},
	}

	for _, currTest := range tests {
		currTest.old.Update(currTest.input)
		assert.EqualValues(t, currTest.old, currTest.new)
	}
}
