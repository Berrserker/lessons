package filters

type Filter interface {
	AsString() string
	isValid() error
}

func AsStrings(input []Filter) []string {
	result := []string{}
	for _, f := range input {
		result = append(result, f.AsString())
	}

	return result
}
