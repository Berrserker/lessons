package parsers

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestParseAvailableFormat(t *testing.T) {
	type formatParserTest struct {
		input  string
		result *AvailableFormat
		err    error
	}

	testsOk := []formatParserTest{
		{
			input: "  E mp4             MP4 (MPEG-4 Part 14)",
			result: &AvailableFormat{
				Name:              "mp4",
				Desc:              "MP4 (MPEG-4 Part 14)",
				DemuxingSupported: true,
				MuxingSupported:   false,
			},
		},
	}

	for _, currTest := range testsOk {
		result, err := ParseAvailableFormat(currTest.input)
		assert.Nil(t, err)
		assert.NotNil(t, result)
		assert.EqualValues(t, currTest.result, result)
	}

	testsFailed := []formatParserTest{
		{
			input: "S ololo Pow-pow-pow",
			err:   ErrBadSubmatch,
		},
	}

	for _, currTest := range testsFailed {
		result, err := ParseAvailableFormat(currTest.input)
		assert.Nil(t, result)
		assert.NotNil(t, err)
		assert.EqualValues(t, currTest.err, err)
	}
}
