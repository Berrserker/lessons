package transcoding

import (
	"gitlab.infra.aiarlabs.com/media/ffmpeg/args"
	"gitlab.infra.aiarlabs.com/media/ffmpeg/transcoding/filters"
)

type Video struct {
	Copy, None  bool
	Codec       *Codec
	Bitrate     *Bitrate
	Mapping     *Mapping
	Crf         int
	Maxrate     int
	Bufsize     int
	Gop         GOP
	FrameRate   float64
	PixelFormat string
	Level       float64
	Filters     []filters.Filter
}

func (v *Video) isValid() error {
	if err := v.Gop.isValid(); err != nil {
		return err
	}

	if v.Codec != nil {
		if err := v.Codec.isValid(); err != nil {
			return err
		}
	}

	if v.Bitrate != nil {
		if err := v.Bitrate.isValid(); err != nil {
			return err
		}
	}

	switch {
	case v.Bufsize < 0:
		return ErrIsNegative
	case v.Maxrate < 0:
		return ErrIsNegative
	case v.FrameRate < 0:
		return ErrIsNegative
	case v.Level < 0:
		return ErrIsNegative
	case v.Crf < 0:
		return ErrIsNegative
	default:
		return nil
	}
}

func (v *Video) getArgs() []string {
	result := []string{}

	if v.None {
		return append(result, args.GetNoneStreamArg(string(VideoStream)))
	}

	if v.Mapping != nil {
		result = append(result, v.Mapping.getArgs()...)
	}

	if v.Copy {
		result = append(result, args.GetCodecCopyArgs(string(VideoStream))...)

		return result
	}

	if v.Codec != nil {
		result = append(result, v.Codec.getArgs(VideoStream)...)
	}

	if v.Bitrate != nil {
		result = append(result, v.Bitrate.getArgs(VideoStream)...)
	}

	if v.Maxrate != 0 {
		result = append(result, args.GetMaxrateArgs(v.Maxrate)...)
	}

	if v.Crf != 0 {
		result = append(result, args.GetCrfArgs(v.Crf)...)
	}

	if v.Bufsize != 0 {
		result = append(result, args.GetBufsizeArgs(v.Bufsize)...)
	}

	if v.FrameRate != 0 {
		result = append(result, args.GetFrameRateArgs(v.FrameRate)...)
	}

	if v.PixelFormat != "" {
		result = append(result, args.GetPixelFormatArgs(v.PixelFormat)...)
	}

	if v.Level != 0 {
		result = append(result, args.GetLevelArgs(v.Level)...)
	}

	result = append(result, v.Gop.getArgs()...)

	if len(v.Filters) != 0 {
		result = append(result, args.GetVideoFiltersArgs(filters.AsStrings(v.Filters))...)
	}

	return result
}
