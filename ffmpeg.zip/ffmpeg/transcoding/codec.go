package transcoding

import "gitlab.infra.aiarlabs.com/media/ffmpeg/args"

type Codec struct {
	Name string
}

func (c *Codec) getArgs(streamType StreamType) []string {
	return args.GetCodecArgs(c.Name, string(streamType))
}

func (c *Codec) isValid() error {
	switch {
	case c.Name == "":
		return ErrIsEmpty
	default:
		return nil
	}
}
