package transcoding

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestMappingToString(t *testing.T) {
	type mappingTests struct {
		mapping Mapping
		result  string
	}

	okTests := []mappingTests{
		{
			mapping: Mapping{
				InputIndex:  0,
				StreamType:  VideoStream,
				StreamIndex: 0,
			},
			result: "0:v:0",
		},
		{
			mapping: Mapping{
				InputIndex:  1,
				StreamType:  AudioStream,
				StreamIndex: 1,
			},
			result: "1:a:1",
		},
		{
			mapping: Mapping{
				InputIndex:  0,
				StreamIndex: 2,
			},
			result: "0:2",
		},
	}

	for _, currTest := range okTests {
		result := currTest.mapping.valueToString()
		assert.Equal(t, currTest.result, result)
	}
}
