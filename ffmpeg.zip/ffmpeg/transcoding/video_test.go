package transcoding

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestVideo(t *testing.T) {
	type videoTests struct {
		video Video
		key   string
		value string
	}

	okTests := []videoTests{
		{
			video: Video{Maxrate: 1000},
			key:   "-maxrate",
			value: "1000",
		},
		{
			video: Video{Bufsize: 3000},
			key:   "-bufsize",
			value: "3000",
		},
		{
			video: Video{FrameRate: float64(30000) / float64(1001)},
			key:   "-r",
			value: "29.970",
		},
		{
			video: Video{Level: 4.0},
			key:   "-level",
			value: "4.0",
		},
		{
			video: Video{PixelFormat: "yuv420p"},
			key:   "-pix_fmt",
			value: "yuv420p",
		},
	}

	for _, currTest := range okTests {
		result := currTest.video.getArgs()
		assert.Len(t, result, 2)
		assert.Equal(t, currTest.key, result[0])
		assert.Equal(t, currTest.value, result[1])
	}
}
