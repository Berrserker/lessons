package parsers

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestParseAvailablePixelFormat(t *testing.T) {
	type pixelFormatParserTest struct {
		input  string
		result *AvailablePixelFormat
		err    error
	}

	testsOk := []pixelFormatParserTest{
		{
			input: "IO... yuv420p                3            12",
			result: &AvailablePixelFormat{
				Name:                             "yuv420p",
				SupportInputFormatForConversion:  true,
				SupportOutputFormatForConversion: true,
				NumberOfComponents:               3,
				BitsPerSample:                    12,
			},
		},
		{
			input: "..H.. cuda                   0             0",
			result: &AvailablePixelFormat{
				Name:                 "cuda",
				HardwareAcceleration: true,
			},
		},
	}

	for _, currTest := range testsOk {
		result, err := ParseAvailablePixelFormat(currTest.input)
		assert.Nil(t, err)
		assert.NotNil(t, result)
		assert.EqualValues(t, currTest.result, result)
	}

	testsFailed := []pixelFormatParserTest{
		{
			input: "IO. yuv420p                3            12",
			err:   ErrBadSubmatch,
		},
	}

	for _, currTest := range testsFailed {
		result, err := ParseAvailableFormat(currTest.input)
		assert.Nil(t, result)
		assert.NotNil(t, err)
		assert.EqualValues(t, currTest.err, err)
	}
}
