package filters

import "fmt"

type SarFilter struct {
	basic
	PixelWidth, PixelHeight int
}

func (sf SarFilter) AsString() string {
	const (
		filterName = "setsar"
		sarKey     = "sar"
	)

	if sf.PixelWidth != 0 && sf.PixelHeight != 0 {
		sf.addParam(sarKey, fmt.Sprintf("%d/%d", sf.PixelWidth, sf.PixelHeight))
	}

	sf.name = filterName

	return sf.asString()
}

func (sf SarFilter) isValid() error {
	switch {
	case sf.PixelHeight < 0:
		return ErrHeightIsNegative
	case sf.PixelWidth < 0:
		return ErrWidthIsNegative
	case sf.PixelWidth == 0 && sf.PixelHeight != 0 ||
		sf.PixelWidth != 0 && sf.PixelHeight == 0:
		return ErrWidthOrHeightIsUnselected
	default:
		return nil
	}
}
