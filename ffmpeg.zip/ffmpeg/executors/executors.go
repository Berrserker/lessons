package executors

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"os/exec"
)

// WithOutput запускает бинарный файл с аргументами. Возвращает буффер байт с stdout.
// В случае проблем с запуском файла - вернет ошибку.
func WithOutput(ctx context.Context, pathToBin string, args []string) (*bytes.Buffer, error) {
	cmd := exec.CommandContext(ctx, pathToBin, args...)

	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	if err := cmd.Run(); err != nil {
		return nil, fmt.Errorf("exec error: %v", stderr.String())
	}

	return &stdout, nil
}

// WithOutputPipe запускает бинарный файл с аргументами. На вход .
// В случае проблем с запуском файла - вернет ошибку.
func WithOutputPipe(ctx context.Context, pathToBin string, args []string, onProgress func(string)) error {
	if onProgress == nil {
		_, err := WithOutput(ctx, pathToBin, args)

		return err
	}

	cmd := exec.CommandContext(ctx, pathToBin, args...)

	var stderr bytes.Buffer
	cmd.Stderr = &stderr

	r, err := cmd.StdoutPipe()
	if err != nil {
		return fmt.Errorf("get stdout pipe error: %v", err)
	}

	done := make(chan struct{})

	scanner := bufio.NewScanner(r)

	go func() {
		for scanner.Scan() {
			onProgress(scanner.Text())
		}
		done <- struct{}{}
	}()

	if err := cmd.Start(); err != nil {
		return fmt.Errorf("exec error: %v", stderr.String())
	}

	<-done

	return cmd.Wait()
}
