package transcoding

import "errors"

var (
	ErrIsEmpty        = errors.New("value can't be empty")
	ErrIsNegative     = errors.New("value can't be negative")
	ErrMaxLessThanMin = errors.New("maximum value can't be less than minimum")
)
