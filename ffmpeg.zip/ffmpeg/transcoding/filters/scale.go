package filters

import "strconv"

type ScaleFilter struct {
	basic
	Width, Height int
}

func (sf ScaleFilter) AsString() string {
	const (
		filterName = "scale"
		widthKey   = "w"
		heightKey  = "h"
	)

	if sf.Width != 0 {
		sf.addParam(widthKey, strconv.Itoa(sf.Width))
	}

	if sf.Height != 0 {
		sf.addParam(heightKey, strconv.Itoa(sf.Height))
	}

	sf.name = filterName

	return sf.asString()
}

func (sf ScaleFilter) isValid() error {
	switch {
	case sf.Height < -2:
		return ErrHeightIsNegative
	case sf.Width < -2:
		return ErrWidthIsNegative
	case sf.Width == 0 && sf.Height != 0 ||
		sf.Width != 0 && sf.Height == 0:
		return ErrWidthOrHeightIsUnselected
	default:
		return nil
	}
}
