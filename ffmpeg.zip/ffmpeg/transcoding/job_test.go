package transcoding

import (
	"testing"

	"github.com/stretchr/testify/assert"

	"gitlab.infra.aiarlabs.com/media/ffmpeg/transcoding/filters"
)

func TestJobGetArgs(t *testing.T) {
	type jobTests struct {
		job    Job
		result string
	}

	okTests := []jobTests{
		{
			job: Job{
				Rewrite: true,
				Inputs:  []Input{{Path: "input.mp4"}},
				Outputs: []Output{
					{
						Path:   "output.mp4",
						Format: "mp4",
						Video: Video{
							Codec:   &Codec{Name: "libx264"},
							Bitrate: &Bitrate{Value: 5 * 1000 * 1024},
							Mapping: &Mapping{
								InputIndex:  0,
								StreamType:  VideoStream,
								StreamIndex: 0,
							},
							Maxrate:     8 * 1000 * 1024,
							Bufsize:     10 * 1000 * 1024,
							Gop:         GOP{Min: 60, Max: 60},
							FrameRate:   30.0,
							PixelFormat: "yuv420p",
							Level:       3.1,
							Filters: []filters.Filter{
								filters.ScaleFilter{Width: 1080, Height: -2},
								filters.SarFilter{PixelWidth: 1, PixelHeight: 1},
							},
						},
						Audio: Audio{
							Codec:   &Codec{Name: "aac"},
							Bitrate: &Bitrate{Value: 128 * 1024},
							Mapping: &Mapping{
								InputIndex:  0,
								StreamType:  AudioStream,
								StreamIndex: 0,
							},
							Channels:   2,
							SampleRate: 44100,
						},
						Movflags: []string{"faststart"},
					},
				},
			},
			result: "0:v:0",
		},
	}

	for _, currTest := range okTests {
		result, err := currTest.job.GetArgs()
		assert.NotNil(t, result)
		assert.Nil(t, err)
	}
}
