package args

// REWRITE

const rewriteArg = "-y"

// HIDE BANNERS

const hideBannerArg = "-hide_banner"

// PROGRESS

const progressArg = "-progress"

// AVAILABLE ENCODERS/DECODERS/FILTERS

const (
	availableDecodersArg     = "-decoders"
	availableEncodersArg     = "-encoders"
	availableFiltersArg      = "-filters"
	availableFormatsArg      = "-formats"
	availablePixelFormatsArg = "-pix_fmts"
)

// LOGLEVEL

const (
	logLevelArg = "-loglevel"

	LogLevelError   LogLevel = "error"
	LogLevelWarning LogLevel = "warning"
	LogLevelInfo    LogLevel = "info"
)

type LogLevel string

// INPUT

const inputArg = "-i"
