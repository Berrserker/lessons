package ffmpeg

import (
	"strconv"
	"strings"
	"time"
)

type Progress struct {
	Frame   int
	Fps     float64
	EndFlag bool
	Size    int
	Time    time.Duration
	Bitrate float64
	Speed   float64
}

func (p *Progress) Update(input string) {
	const keyValLen = 2

	keyVal := strings.Split(input, "=")
	if len(keyVal) != keyValLen {
		return
	}

	key := keyVal[0]
	value := keyVal[1]

	switch key {
	case "frame":
		frame, err := strconv.Atoi(value)
		if err == nil {
			p.Frame = frame
		}
	case "fps":
		fps, err := strconv.ParseFloat(value, 64)
		if err == nil {
			p.Fps = fps
		}
	case "bitrate":
		bitrate := strings.ReplaceAll(value, "kbits/s", "")

		bitrateParsed, err := strconv.ParseFloat(bitrate, 64)
		if err == nil {
			p.Bitrate = bitrateParsed
		}
	case "total_size":
		size, err := strconv.Atoi(value)
		if err == nil {
			p.Size = size
		}
	case "out_time_us", "out_time_ms":
		t, err := strconv.Atoi(value)
		if err == nil {
			p.Time = time.Duration(t) * time.Nanosecond
		}
	case "progress":
		if value == "end" {
			p.EndFlag = true
		}
	case "speed":
		speed := strings.ReplaceAll(value, "x", "")

		speedParsed, err := strconv.ParseFloat(speed, 64)
		if err == nil {
			p.Speed = speedParsed
		}
	default:
		return
	}
}
