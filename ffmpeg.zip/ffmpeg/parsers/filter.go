package parsers

import (
	"regexp"
	"strings"
)

type AvailableFilter struct {
	Name            string
	Desc            string
	TimelineSupport bool
	SliceThreading  bool
	CommandSupport  bool
	Input, Output   FilterIO
}

func ParseAvailableFilter(input string) (*AvailableFilter, error) {
	const (
		rExpr       = `^\s*(\w+|.)(\w+|.)(\w|.)\s+(\S+)\s+(\S+)->(\S)\s+(.+)$`
		totalParams = 8
	)

	r, err := regexp.Compile(rExpr)
	if err != nil {
		return nil, err
	}

	subm := r.FindStringSubmatch(input)
	if len(subm) < totalParams {
		return nil, ErrBadSubmatch
	}

	return &AvailableFilter{
		Name:            subm[4],
		Desc:            subm[7],
		TimelineSupport: subm[1] != ".",
		SliceThreading:  subm[2] != ".",
		CommandSupport:  subm[3] != ".",
		Input:           parseIO(subm[5]),
		Output:          parseIO(subm[6]),
	}, nil
}

type FilterIO struct {
	ioType IOType
	count  int
}

func (i *FilterIO) IsUnlimited() bool { return i.ioType == IODynamic }

func parseIO(value string) (result FilterIO) {
	f := strings.Split(value, "")
	result.ioType = parseIOType(f[0])

	if result.ioType != IODynamic {
		result.count = len(f)
	}

	return
}
